# numeric.py

__all__ = ['is_integer', 'is_numeric']


def is_integer(arg):
    pass


def is_numeric(arg):
    pass


def numeric_helper_1():
    pass


def numeric_helper_2():
    pass
